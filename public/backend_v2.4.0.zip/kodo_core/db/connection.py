"""
kodo_core.db.connection - Gestionnaire de connexion SQLite thread-safe avec mode WAL,
pragmas de performance, row factory et convertisseur Decimal.
"""

import sqlite3
import os
import hashlib
import hmac
import logging
from typing import Tuple, Optional
from decimal import Decimal
from contextlib import contextmanager
from kodo_core.config import ShopConfig

logger = logging.getLogger("kodo.db.connection")

# -----------------------------------------------------------------------------
# Convertisseurs et adaptateurs pour le type Decimal dans SQLite
# -----------------------------------------------------------------------------
def adapt_decimal(d: Decimal) -> str:
    """Convertit un objet Decimal en chaîne pour SQLite."""
    return str(d)

def convert_decimal(s: bytes) -> Decimal:
    """Reconvertit une valeur binaire/texte SQLite en objet Decimal Python."""
    return Decimal(s.decode('utf-8'))

# Enregistrement global des adaptateurs SQLite
sqlite3.register_adapter(Decimal, adapt_decimal)
sqlite3.register_converter("DECIMAL", convert_decimal)
sqlite3.register_converter("decimal", convert_decimal)

def hash_pin_sha256(pin_plain: str, salt: str = None) -> str:
    """Ancien hachage SHA-256 avec sel (conservé pour rétrocompatibilité)."""
    if not pin_plain:
        return ""
    s = salt or ShopConfig.get_salt()
    return hashlib.sha256((str(pin_plain) + s).encode('utf-8')).hexdigest()


def hash_pin(pin_plain: str, salt: str = None) -> str:
    """Génère un hachage PBKDF2-HMAC-SHA256 à 100 000 itérations (64 caractères hex déterministes)."""
    if not pin_plain:
        return ""
    s = salt or ShopConfig.get_salt()
    return hashlib.pbkdf2_hmac('sha256', (str(pin_plain) + s).encode('utf-8'), s.encode('utf-8'), 100_000).hex()


def verify_pin_hash(pin_plain: str, stored_hash: str, salt: str = None) -> Tuple[bool, bool]:
    """Vérifie un code PIN contre une empreinte (PBKDF2 ou SHA-256 legacy, avec support rehash)."""
    if not pin_plain or not stored_hash:
        return False, False
    current_salt = salt or ShopConfig.get_salt()
    # 1. PBKDF2 avec le sel courant
    pbkdf2_h = hash_pin(pin_plain, current_salt)
    if hmac.compare_digest(pbkdf2_h, stored_hash):
        return True, False
    # 2. SHA-256 legacy avec le sel courant
    legacy_h = hash_pin_sha256(pin_plain, current_salt)
    if hmac.compare_digest(legacy_h, stored_hash):
        return True, True
    # 3. Repli PBKDF2 / SHA-256 avec sel statique historique (pour migration transparente)
    legacy_static = "KODO_POS_SECURE_SALT_2026"
    if current_salt != legacy_static:
        pbkdf2_static = hash_pin(pin_plain, legacy_static)
        if hmac.compare_digest(pbkdf2_static, stored_hash):
            return True, True
        sha_static = hash_pin_sha256(pin_plain, legacy_static)
        if hmac.compare_digest(sha_static, stored_hash):
            return True, True
    return False, False

class SafeConnection:
    """
    Wrapper de connexion SQLite ultra-sécurisé et thread-safe.
    Garantit l'activation du mode WAL, l'application des pragmas de performance,
    la conversion des Rows et la fermeture sans fuite de descripteur.
    """

    def __init__(self, db_path: str = None, conn: sqlite3.Connection = None, **kwargs):
        if conn is not None:
            self._conn = conn
            self._external_conn = True
        else:
            self.db_path = db_path or ShopConfig.get_db_path()
            os.makedirs(os.path.dirname(os.path.abspath(self.db_path)), exist_ok=True)
            self._closed = False
            self._external_conn = False
            
            if "detect_types" not in kwargs:
                kwargs["detect_types"] = sqlite3.PARSE_DECLTYPES | sqlite3.PARSE_COLNAMES
            
            self._conn = sqlite3.connect(self.db_path, **kwargs)

        self._conn.row_factory = sqlite3.Row
        self._closed = False
        self._apply_pragmas()

    def _apply_pragmas(self):
        """Applique les pragmas SQLite de performance et de cohérence relationnelle."""
        try:
            cur = self._conn.cursor()
            cur.execute("PRAGMA journal_mode=WAL")
            cur.execute("PRAGMA busy_timeout=5000")
            cur.execute("PRAGMA synchronous=NORMAL")
            cur.execute("PRAGMA foreign_keys=ON")
            cur.execute("PRAGMA temp_store=MEMORY")
        except Exception as exc:
            logger.warning("Échec application des PRAGMAs SQLite : %s", exc)

    def cursor(self) -> sqlite3.Cursor:
        return self._conn.cursor()

    def execute(self, *args, **kwargs) -> sqlite3.Cursor:
        return self._conn.execute(*args, **kwargs)

    def executemany(self, *args, **kwargs) -> sqlite3.Cursor:
        return self._conn.executemany(*args, **kwargs)

    def commit(self):
        self._conn.commit()

    def rollback(self):
        try:
            self._conn.rollback()
        except Exception as exc:
            logger.debug("Rollback SQLite ignoré : %s", exc)

    def close(self):
        if not self._closed:
            if not self._external_conn:
                try:
                    self._conn.close()
                except Exception as exc:
                    logger.debug("Fermeture connexion SQLite ignorée : %s", exc)
            self._closed = True

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            self.rollback()
        else:
            self.commit()
        self.close()

    @property
    def in_transaction(self) -> bool:
        return getattr(self._conn, "in_transaction", False)

    def __getattr__(self, name):
        return getattr(self._conn, name)

    def __del__(self):
        self.close()

def get_connection(db_path: str = None, conn: sqlite3.Connection = None) -> SafeConnection:
    """Retourne une instance fermable de SafeConnection."""
    return SafeConnection(db_path=db_path, conn=conn)

@contextmanager
def db_transaction(db_path: str = None, conn: sqlite3.Connection = None):
    """
    Gestionnaire de contexte de transaction atomique avec réservation immédiate du verrou d'écriture (BEGIN IMMEDIATE).
    Valide (commit) automatiquement si aucune exception n'est levée, sinon annule (rollback).
    """
    connection = get_connection(db_path=db_path, conn=conn)
    try:
        # Réservation immédiate du verrou d'écriture, sauf si l'appelant a déjà ouvert une
        # transaction sur cette connexion : un BEGIN imbriqué lève OperationalError, et le
        # rollback de ce gestionnaire annulerait alors les écritures en attente de l'appelant.
        if not connection._conn.in_transaction:
            connection.execute("BEGIN IMMEDIATE")
        cursor = connection.cursor()
        yield cursor
        connection.commit()
    except Exception as e:
        connection.rollback()
        raise e
    finally:
        connection.close()

@contextmanager
def db_query(db_path: str = None, conn: sqlite3.Connection = None):
    """Gestionnaire de contexte en lecture seule pour requêtes SQLite."""
    connection = get_connection(db_path=db_path, conn=conn)
    try:
        cursor = connection.cursor()
        yield cursor
    finally:
        connection.close()
